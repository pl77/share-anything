from share.hosts import anonfile
from share.hosts import gist
from share.hosts import imgur